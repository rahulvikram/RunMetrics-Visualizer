# RunMetrics Visualizer
### A handy developer tool for storing function runtime data and graphing it via GUI!